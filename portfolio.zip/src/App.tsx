import { useState, useCallback } from 'react'
import { Container } from 'react-bootstrap'
import { AnimatePresence } from 'framer-motion'
import Navigation from './components/Navigation.tsx'
import Hero from './components/Hero.tsx'
import Experience from './components/Experience.tsx'
import Projects from './components/Projects.tsx'
import Skills from './components/Skills.tsx'
import Contact from './components/Contact.tsx'
import Footer from './components/Footer.tsx'
import FloatingLines from './components/FloatingLines.tsx'
import Intro3D from './components/Intro3D.tsx'
import ScrollReveal from './components/ScrollReveal.tsx'
import './App.css'

// Static color palettes — gradient lerp is handled inside FloatingLines
const BASE_COLORS   = ['#00d2ff', '#3a7bd5', '#7c3aed', '#c084fc']
const SCROLL_COLORS = ['#ff1a40', '#ff6a00', '#c084fc', '#38bdf8']

function MainContent() {
  return (
    <div className="app-container">

      {/* Dark base so lines have contrast */}
      <div style={{ position: 'fixed', inset: 0, background: '#050a14', zIndex: 0 }} />

      {/* FloatingLines full-screen background — owns its own scroll listener */}
      <div style={{ position: 'fixed', inset: 0, zIndex: 1, pointerEvents: 'none' }}>
        <FloatingLines
          enabledWaves={['top', 'middle', 'bottom']}
          lineCount={6}
          lineDistance={6}
          bendRadius={6}
          bendStrength={-0.6}
          interactive={true}
          parallax={true}
          parallaxStrength={0.2}
          animationSpeed={0.8}
          linesGradient={BASE_COLORS}
          scrollColors={SCROLL_COLORS}
          scrollIdleMs={800}
          mixBlendMode="screen"
        />
      </div>

      <Navigation />
      
      <main style={{ position: 'relative', zIndex: 2 }}>
        <Hero />
        
        <section className="quote-section py-5 my-5">
          <Container>
            <ScrollReveal
              baseOpacity={0.02}
              enableBlur
              baseRotation={6}
              blurStrength={12}
            >
              When does a man die? When he is hit by a bullet? No! When he suffers a disease? No! When he ate a soup made out of a poisonous mushroom? No! A man dies when he is forgotten!
            </ScrollReveal>
          </Container>
        </section>

        <Container>
          <Experience />
          <Projects />
          <Skills />
          <Contact />
        </Container>
      </main>

      <Footer />
    </div>
  )
}

function App() {
  const [showIntro, setShowIntro] = useState(true)

  const handleIntroComplete = useCallback(() => {
    setShowIntro(false)
  }, [])

  return (
    <div className="app-container">
      <AnimatePresence mode="wait">
        {showIntro ? (
          <Intro3D key="intro" onComplete={handleIntroComplete} />
        ) : (
          <MainContent key="content" />
        )}
      </AnimatePresence>
    </div>
  )
}

export default App
