import { Container } from 'react-bootstrap'
import GooeyNav from './GooeyNav'
import Magnetic from './Magnetic'

const navItems = [
  { label: "Home", href: "#home" },
  { label: "Experience", href: "#experience" },
  { label: "Projects", href: "#projects" },
  { label: "Skills", href: "#skills" },
  { label: "Contact", href: "#contact" },
]

const Navigation = () => {
  return (
    <nav className="fixed-top py-3" style={{ background: 'transparent' }}>
      <Container className="d-flex justify-content-between align-items-center">
        <Magnetic>
          <a href="#home" className="fw-bold fs-3 text-decoration-none" style={{ zIndex: 10 }}>
            <span className="text-gradient">Rohith K</span>
          </a>
        </Magnetic>
        
        <GooeyNav
          items={navItems}
          particleCount={15}
          particleDistances={[90, 10]}
          particleR={100}
          initialActiveIndex={0}
          animationTime={600}
          timeVariance={300}
          colors={[1, 2, 3, 1, 2, 3, 1, 4]}
        />
      </Container>
    </nav>
  )
}

export default Navigation
