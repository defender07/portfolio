import { motion } from 'framer-motion'
import { Row, Col } from 'react-bootstrap'
import BorderGlow from './BorderGlow'
import DecryptedText from './DecryptedText'

const Skills = () => {
  const skillCategories = [
    {
      name: 'Languages',
      skills: ['JavaScript', 'TypeScript', 'Python', 'Dart', 'Java', 'C']
    },
    {
      name: 'Frontend',
      skills: ['React.js', 'HTML5', 'CSS3', 'Bootstrap', 'Flutter']
    },
    {
      name: 'Backend & DB',
      skills: ['Node.js', 'Express.js', 'Nest.js', 'MongoDB', 'PostgreSQL', 'MySQL', 'SQLite']
    },
    {
      name: 'AI / ML',
      skills: ['Scikit-learn', 'TensorFlow', 'PyTorch', 'KNN', 'K-Means', 'ANN', 'RecSys']
    },
    {
      name: 'Cloud & Tools',
      skills: ['AWS (EC2, S3)', 'Cloudflare', 'Git', 'GitHub', 'Postman', 'VS Code', 'Android Studio']
    }
  ]

  return (
    <section id="skills" className="py-5">
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ duration: 1 }}
        viewport={{ once: true }}
      >
        <div className="text-center mb-5">
          <span className="text-primary fw-bold text-uppercase small ls-widest d-block mb-3" style={{ letterSpacing: '0.15em' }}>Capabilities</span>
          <h2 className="display-4 fw-bold">Technical <span className="text-gradient">Proficiency</span></h2>
        </div>

        <Row className="g-4">
          {skillCategories.map((cat, index) => (
            <Col lg={4} md={6} key={index}>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="h-100"
              >
                <BorderGlow
                  edgeSensitivity={30}
                  glowColor="40 80 80"
                  backgroundColor="#060010"
                  borderRadius={28}
                  glowRadius={40}
                  glowIntensity={1}
                  coneSpread={25}
                  animated={false}
                  colors={['#c084fc', '#f472b6', '#38bdf8']}
                  className="p-4 p-md-5 h-100"
                >
                  <h3 className="h6 fw-bold text-primary mb-4 pb-2 border-bottom border-white border-opacity-5 text-uppercase ls-widest" style={{ letterSpacing: '0.1em' }}>
                    {cat.name}
                  </h3>
                  <div className="d-flex flex-wrap gap-4">
                    {cat.skills.map((skill, sIdx) => (
                      <DecryptedText
                        key={sIdx}
                        text={skill}
                        animateOn="hover"
                        revealDirection="center"
                        className="text-white fw-bold"
                        encryptedClassName="text-muted"
                        speed={40}
                        sequential
                        style={{ cursor: 'pointer', fontSize: '1rem', letterSpacing: '0.02em' }}
                      />
                    ))}
                  </div>
                </BorderGlow>
              </motion.div>
            </Col>
          ))}
        </Row>
      </motion.div>
    </section>
  )
}

export default Skills
