import { Container } from 'react-bootstrap'

const Footer = () => {
  return (
    <footer className="py-5 border-top border-white border-opacity-5 mt-5">
      <Container className="text-center">
        <p className="text-muted mb-2 small fw-bold text-uppercase ls-widest" style={{ letterSpacing: '0.1em' }}>
          © {new Date().getFullYear()} Rohith K
        </p>
        <p className="text-white-50 small mb-0">
          Engineered for <span className="text-primary fw-bold">excellence</span> and interactive storytelling.
        </p>
      </Container>
    </footer>
  )
}

export default Footer
