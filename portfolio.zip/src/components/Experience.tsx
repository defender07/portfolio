import { motion } from 'framer-motion'
import { Row, Col, Badge } from 'react-bootstrap'
import BorderGlow from './BorderGlow'

const Experience = () => {
  const experiences = [
    {
      role: 'Flutter Full Stack Developer',
      company: 'UFS Technologies, Kochi',
      period: 'Present',
      description: 'Developing high-performance cross-platform applications and scalable backend systems. Specialized in real-time location tracking and complex data synchronization.',
      skills: ['Flutter', 'Node.js', 'MySQL', 'REST APIs', 'Location Tracking']
    },
    {
      role: 'Flutter Developer Trainee',
      company: 'Resab Technology, Kozhikode',
      period: 'May 2024 - Oct 2025',
      description: 'Built robust mobile solutions with advanced state management. Focused on API integration and UI/UX optimization for consumer-facing apps.',
      skills: ['Flutter', 'REST APIs', 'BLoC', 'Dart']
    },
    {
      role: 'Flutter Developer Intern',
      company: 'C-DIT, Thiruvananthapuram',
      period: 'Jan 2024 - Apr 2024',
      description: 'Engineered secure mobile applications with biometric authentication and local persistent storage solutions.',
      skills: ['Flutter', 'Biometric Auth', 'SQLite', 'Mobile Development']
    }
  ]

  return (
    <section id="experience" className="py-5">
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ duration: 1 }}
        viewport={{ once: true }}
      >
        <span className="text-primary fw-bold text-uppercase small ls-widest d-block mb-3" style={{ letterSpacing: '0.15em' }}>Journey</span>
        <h2 className="display-4 fw-bold mb-5">Professional <span className="text-gradient">Experience</span></h2>
        
        <div className="timeline">
          {experiences.map((exp, index) => (
            <motion.div
              key={index}
              className="mb-5"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <BorderGlow
                edgeSensitivity={30}
                glowColor="40 80 80"
                backgroundColor="#060010"
                borderRadius={28}
                glowRadius={40}
                glowIntensity={1}
                coneSpread={25}
                animated={false}
                colors={['#c084fc', '#f472b6', '#38bdf8']}
                className="p-5"
              >
                <Row className="align-items-start">
                  <Col md={8}>
                    <h3 className="h4 text-white fw-bold mb-2">{exp.role}</h3>
                    <h4 className="h6 text-primary fw-bold mb-4 opacity-75">{exp.company}</h4>
                    <p className="text-muted mb-4 lead fs-6">{exp.description}</p>
                    <div className="d-flex flex-wrap gap-2">
                      {exp.skills.map((skill, sIdx) => (
                        <Badge key={sIdx} bg="transparent" className="text-primary border border-primary border-opacity-25 px-3 py-2 rounded-pill fw-normal">{skill}</Badge>
                      ))}
                    </div>
                  </Col>
                  <Col md={4} className="text-md-end mt-4 mt-md-0">
                    <span className="text-primary small fw-bold bg-primary bg-opacity-10 px-3 py-2 rounded-pill border border-primary border-opacity-10">{exp.period}</span>
                  </Col>
                </Row>
              </BorderGlow>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </section>
  )
}

export default Experience
