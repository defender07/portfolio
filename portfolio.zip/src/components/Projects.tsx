import { motion } from 'framer-motion'
import { Row, Col, Badge } from 'react-bootstrap'
import BorderGlow from './BorderGlow'

const Projects = () => {
  const projects = [
    {
      title: 'Events Weddora Platform',
      description: 'A comprehensive full-stack event orchestration system. Features secure multi-role authentication, integrated payment processing, and high-performance recommendation engines.',
      tech: ['React.js', 'Node.js', 'MongoDB', 'AI/ML'],
      link: '#',
    },
    {
      title: 'Production Mobile Ecosystem',
      description: 'Mission-critical Flutter environment featuring encrypted local storage, real-time telemetry, and enterprise-grade biometric security protocols.',
      tech: ['Flutter', 'Node.js', 'Biometrics', 'Real-time Data'],
      link: '#',
    }
  ]

  return (
    <section id="projects" className="py-5">
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ duration: 1 }}
        viewport={{ once: true }}
      >
        <div className="text-center mb-5">
          <span className="text-primary fw-bold text-uppercase small ls-widest d-block mb-3" style={{ letterSpacing: '0.15em' }}>Portfolio</span>
          <h2 className="display-4 fw-bold">Featured <span className="text-gradient">Projects</span></h2>
        </div>

        <Row className="g-4 justify-content-center">
          {projects.map((project, index) => (
            <Col lg={5} md={6} key={index}>
              <motion.div
                whileHover={{ y: -8 }}
                transition={{ type: 'spring', stiffness: 200 }}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
              >
                <BorderGlow
                  edgeSensitivity={30}
                  glowColor="40 80 80"
                  backgroundColor="#060010"
                  borderRadius={28}
                  glowRadius={40}
                  glowIntensity={1}
                  coneSpread={25}
                  animated={false}
                  colors={['#c084fc', '#f472b6', '#38bdf8']}
                  className="p-5"
                >
                  <div className="d-flex flex-column">
                    <h3 className="h3 fw-bold text-white mb-3">{project.title}</h3>
                    <p className="text-muted mb-4 lead fs-6">
                      {project.description}
                    </p>
                    <div className="mb-4">
                      <div className="d-flex flex-wrap gap-2 mb-4">
                        {project.tech.map((t, tIdx) => (
                          <Badge key={tIdx} bg="transparent" className="text-primary border border-primary border-opacity-25 px-3 py-2 rounded-pill fw-normal">{t}</Badge>
                        ))}
                      </div>
                      <a href={project.link} className="btn btn-outline-primary rounded-pill px-4 fw-bold">Case Study</a>
                    </div>
                  </div>
                </BorderGlow>
              </motion.div>
            </Col>
          ))}
        </Row>
      </motion.div>
    </section>
  )
}

export default Projects
