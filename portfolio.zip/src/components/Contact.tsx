import { Row, Col, Form } from 'react-bootstrap'
import { motion } from 'framer-motion'
import { Mail, Globe, User, Send } from 'lucide-react'
import BorderGlow from './BorderGlow'

const Contact = () => {
  return (
    <section id="contact" className="py-5">
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ duration: 1 }}
        viewport={{ once: true }}
      >
        <div className="text-center mb-5">
          <span className="text-primary fw-bold text-uppercase small ls-widest d-block mb-3" style={{ letterSpacing: '0.15em' }}>Inquiry</span>
          <h2 className="display-4 fw-bold">Let's <span className="text-gradient">Connect</span></h2>
        </div>

        <Row className="justify-content-center">
          <Col lg={11}>
            <BorderGlow
              edgeSensitivity={30}
              glowColor="40 80 80"
              backgroundColor="#060010"
              borderRadius={28}
              glowRadius={40}
              glowIntensity={1}
              coneSpread={25}
              animated={false}
              colors={['#c084fc', '#f472b6', '#38bdf8']}
            >
              <Row className="g-0">
                <Col md={5} className="p-4 p-md-5" style={{ background: 'rgba(255,255,255,0.01)', borderRadius: '24px 0 0 24px' }}>
                  <h3 className="h4 text-white mb-4 fw-bold">Contact Information</h3>
                  <p className="text-muted mb-5 lead fs-6">
                    I'm currently specialized in building high-performance digital ecosystems. Whether you have a specific inquiry or just want to collaborate, I'm just an email away.
                  </p>
                  
                  <motion.div
                    className="mb-5 d-flex align-items-center"
                    whileHover={{ x: 10 }}
                  >
                    <div className="bg-primary bg-opacity-10 p-3 rounded-circle me-3 border border-primary border-opacity-20">
                      <Mail className="text-primary" size={20} />
                    </div>
                    <div>
                      <div className="text-muted small fw-bold">EMAIL</div>
                      <a href="mailto:njrrohith052@gmail.com" className="text-white fw-bold text-decoration-none">njrrohith052@gmail.com</a>
                    </div>
                  </motion.div>

                  <div className="d-flex gap-3">
                    <motion.a href="https://github.com/defender07" target="_blank" rel="noopener noreferrer"
                      className="bg-white bg-opacity-5 p-3 rounded-4 text-primary border border-white border-opacity-5"
                      whileHover={{ y: -5, background: 'rgba(255,255,255,0.08)' }}
                    >
                      <Globe size={20} />
                    </motion.a>
                    <motion.a href="#" target="_blank" rel="noopener noreferrer"
                      className="bg-white bg-opacity-5 p-3 rounded-4 text-primary border border-white border-opacity-5"
                      whileHover={{ y: -5, background: 'rgba(255,255,255,0.08)' }}
                    >
                      <User size={20} />
                    </motion.a>
                  </div>
                </Col>

                <Col md={7} className="p-4 p-md-5">
                  <Form>
                    <Row>
                      <Col md={6} className="mb-4">
                        <Form.Group controlId="name">
                          <Form.Label className="text-muted small fw-bold mb-2">FULL NAME</Form.Label>
                          <Form.Control type="text" className="border border-white border-opacity-5 text-white p-3 rounded-3" style={{ background: 'rgba(255,255,255,0.03)' }} placeholder="John Doe" />
                        </Form.Group>
                      </Col>
                      <Col md={6} className="mb-4">
                        <Form.Group controlId="email">
                          <Form.Label className="text-muted small fw-bold mb-2">EMAIL ADDRESS</Form.Label>
                          <Form.Control type="email" className="border border-white border-opacity-5 text-white p-3 rounded-3" style={{ background: 'rgba(255,255,255,0.03)' }} placeholder="john@example.com" />
                        </Form.Group>
                      </Col>
                    </Row>
                    <Form.Group className="mb-5" controlId="message">
                      <Form.Label className="text-muted small fw-bold mb-2">YOUR MESSAGE</Form.Label>
                      <Form.Control as="textarea" rows={4} className="border border-white border-opacity-5 text-white p-3 rounded-3" style={{ background: 'rgba(255,255,255,0.03)' }} placeholder="Tell me about your project..." />
                    </Form.Group>
                    <motion.button
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.99 }}
                      type="submit"
                      className="btn btn-primary btn-lg w-100 py-3 fw-bold rounded-pill shadow-lg d-flex align-items-center justify-content-center gap-2"
                    >
                      Send Message <Send size={18} />
                    </motion.button>
                  </Form>
                </Col>
              </Row>
            </BorderGlow>
          </Col>
        </Row>
      </motion.div>
    </section>
  )
}

export default Contact
