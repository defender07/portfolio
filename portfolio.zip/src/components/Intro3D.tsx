import { useState, useEffect, useRef, memo } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import LaserFlow from './LaserFlow'
import portrait from '../assets/portrait.jpg'

interface Intro3DProps {
  onComplete: () => void
}

const Intro3D = ({ onComplete }: Intro3DProps) => {
  const [progress, setProgress] = useState(0)
  const [isLoaded, setIsLoaded] = useState(false)
  const revealImgRef = useRef<HTMLImageElement>(null)

  const completedRef = useRef(false)

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          if (!completedRef.current) {
            completedRef.current = true
            clearInterval(interval)
            setTimeout(() => setIsLoaded(true), 1000)
            setTimeout(() => onComplete(), 5500)
          }
          return 100
        }
        return prev + 1
      })
    }, 40)
    return () => clearInterval(interval)
  }, [onComplete])

  const handleMouseMove = (e: React.MouseEvent) => {
    const el = revealImgRef.current
    if (el) {
      const rect = e.currentTarget.getBoundingClientRect()
      const x = e.clientX - rect.left
      const y = e.clientY - rect.top
      el.style.setProperty('--mx', `${x}px`)
      el.style.setProperty('--my', `${y}px`)
    }
  }

  const handleMouseLeave = () => {
    const el = revealImgRef.current
    if (el) {
      el.style.setProperty('--mx', '-9999px')
      el.style.setProperty('--my', '-9999px')
    }
  }

  return (
    <motion.div
      className="intro-container"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.1, filter: 'blur(20px)' }}
      transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1] }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 9999,
        background: '#050505',
        overflow: 'hidden',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }}
    >
      <div style={{ position: 'absolute', inset: 0, zIndex: 1 }}>
        <LaserFlow
          color="#00d2ff"
          wispDensity={1.5}
          fogIntensity={0.6}
          flowSpeed={0.5}
        />
      </div>

      <div className="z-10 text-center relative" style={{ zIndex: 10, width: '100%', maxWidth: '800px' }}>
        <AnimatePresence>
          {!isLoaded ? (
            <motion.div
              key="loading"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="px-4"
            >
              <h2 className="display-4 fw-bold text-white mb-4 tracking-tighter" style={{ letterSpacing: '-0.05em' }}>
                INITIALIZING <span className="text-gradient">EXCELLENCE</span>
              </h2>
              <div 
                className="progress-bg mx-auto mb-3" 
                style={{ 
                  height: '2px', 
                  width: '100%', 
                  background: 'rgba(255,255,255,0.1)',
                  borderRadius: '10px',
                  overflow: 'hidden',
                  position: 'relative'
                }}
              >
                <motion.div
                  className="progress-bar-fill"
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  style={{
                    height: '100%',
                    background: 'linear-gradient(90deg, #00d2ff, #3a7bd5)',
                    boxShadow: '0 0 20px rgba(0, 210, 255, 0.5)'
                  }}
                />
              </div>
              <p className="text-secondary small fw-bold">{progress}%</p>
            </motion.div>
          ) : (
            <motion.div
              key="portrait"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1, ease: 'easeOut' }}
              className="position-relative mx-auto"
              style={{ width: '400px', height: '400px' }}
            >
              {/* Background Glow */}
              <div 
                style={{
                  position: 'absolute',
                  inset: '-20px',
                  background: 'radial-gradient(circle, rgba(0,210,255,0.2) 0%, transparent 70%)',
                  borderRadius: '50%',
                  zIndex: -1
                }}
              />
              
              <div style={{
                position: 'relative',
                width: '100%',
                height: '100%',
                borderRadius: '32px',
                border: '1px solid rgba(255,255,255,0.1)',
                overflow: 'hidden',
                background: '#0a0a0a',
                boxShadow: '0 40px 80px rgba(0,0,0,0.5)'
              }}>
                <img
                  ref={revealImgRef}
                  src={portrait}
                  alt="Rohith K"
                  style={{
                    width: '100%',
                    height: '100%',
                    objectFit: 'cover',
                    opacity: 1,
                    pointerEvents: 'none',
                    '--mx': '-9999px',
                    '--my': '-9999px',
                    WebkitMaskImage: 'radial-gradient(circle at var(--mx) var(--my), rgba(255,255,255,1) 0px, rgba(255,255,255,0.95) 80px, rgba(255,255,255,0.5) 150px, rgba(255,255,255,0) 250px)',
                    maskImage: 'radial-gradient(circle at var(--mx) var(--my), rgba(255,255,255,1) 0px, rgba(255,255,255,0.95) 80px, rgba(255,255,255,0.5) 150px, rgba(255,255,255,0) 250px)',
                    WebkitMaskRepeat: 'no-repeat',
                    maskRepeat: 'no-repeat'
                  } as any}
                />
                <div style={{
                  position: 'absolute',
                  inset: 0,
                  background: 'linear-gradient(to bottom, transparent 60%, rgba(0,0,0,0.8))',
                  display: 'flex',
                  alignItems: 'flex-end',
                  justifyContent: 'center',
                  paddingBottom: '20px'
                }}>
                  <h3 className="text-white h4 fw-bold">ROHITH K</h3>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  )
}

export default memo(Intro3D)
