import { motion } from 'framer-motion'
import { Container, Row, Col } from 'react-bootstrap'
import Magnetic from './Magnetic'

const Hero = () => {
  return (
    <section id="home" className="d-flex align-items-center" style={{ minHeight: '100vh', position: 'relative' }}>
      <Container>
        <Row className="align-items-center">
          <Col lg={9}>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1 }}
            >
              <motion.span 
                className="text-primary mb-4 d-block fw-bold ls-widest text-uppercase small"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                style={{ letterSpacing: '0.2em' }}
              >
                Available for new opportunities
              </motion.span>
              
              <motion.h1 
                className="display-1 fw-bold mb-4"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
              >
                Hi, I'm <span className="text-gradient">Rohith K</span><br />
                <span className="text-white">Full Stack </span> 
                <span className="text-muted">Architect.</span>
              </motion.h1>

              <motion.h2 
                className="h4 text-muted mb-5 fw-normal lh-base"
                style={{ maxWidth: '700px' }}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
              >
                I specialize in engineering <span className="text-white fw-bold">high-performance</span> digital ecosystems 
                using <span className="text-primary fw-bold">Flutter</span>, <span className="text-primary fw-bold">React</span>, and <span className="text-primary fw-bold">AI</span> integrations. 
                Bridging the gap between complex logic and immersive user experiences.
              </motion.h2>

              <motion.div 
                className="d-flex flex-wrap gap-4"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
              >
                <Magnetic>
                  <a className="btn btn-primary btn-lg px-5 rounded-pill fw-bold" href="#experience">
                    Experience
                  </a>
                </Magnetic>
                <Magnetic>
                  <a className="btn btn-outline-primary btn-lg px-5 rounded-pill fw-bold" href="#contact">
                    Get in touch
                  </a>
                </Magnetic>
              </motion.div>
            </motion.div>
          </Col>
        </Row>
      </Container>
    </section>
  )
}

export default Hero
